console.log('Antes de modificar');
console.log(document.querySelector('h1').innerHTML);
document.querySelector('h1').innerHTML="Javascript - DOM";
console.log('Depois de modificar');
console.log(document.querySelector('h1').innerHTML);